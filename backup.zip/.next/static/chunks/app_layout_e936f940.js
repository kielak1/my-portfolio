(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_e936f940.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_e936f940.js",
  "chunks": [
    "static/chunks/[root of the server]__a6f7b132._.css"
  ],
  "source": "dynamic"
});
